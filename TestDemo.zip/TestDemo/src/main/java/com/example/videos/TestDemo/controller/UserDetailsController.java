/**
 * 
 */
package com.example.videos.TestDemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.videos.TestDemo.model.User;
import com.example.videos.TestDemo.repositories.UserRepository;

/**
 * @author sanjayakumar.das
 *
 */
@RestController
@RequestMapping("/userDetails")
public class UserDetailsController {
	
	@Autowired
	private UserRepository userRepository;
	
	@GetMapping(value="/findAllUserDetails")
	public List<User> getAllUserDetails(){
		return userRepository.findAll();
	}
	
	@GetMapping(value="/{name}")
	public User getUserDetails(@PathVariable final String name){		
		return userRepository.findByName(name);
	}
	
	@PostMapping(value="/saveUserDetails")
	public User saveUserDetails(@RequestBody final User user){
		userRepository.save(user);
		System.out.println("User Data Persisted Successfully**************");
		return userRepository.findByName(user.getName());
	}
	
}