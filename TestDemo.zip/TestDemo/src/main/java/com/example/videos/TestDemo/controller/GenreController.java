/**
 * 
 */
package com.example.videos.TestDemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.videos.TestDemo.model.Genre;
import com.example.videos.TestDemo.repositories.GenreRepository;

/**
 * @author sanjayakumar.das
 *
 */
@RestController
@RequestMapping("/genreType")
public class GenreController {
	
	@Autowired
	private GenreRepository genreRepository;
	
	@GetMapping(value="/findAllGenres")
	public List<Genre> findAllGenres(){
		return genreRepository.findAll();		
	}
	
	@PostMapping(value="/saveGenres")
	public void saveGenres(@RequestBody final Genre genre){
		genreRepository.save(genre);	
		System.out.println("Genre Data Persisted Successfully**************");
	}

}