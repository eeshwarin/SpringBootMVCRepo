/**
 * 
 */
package com.example.videos.TestDemo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.videos.TestDemo.model.UserPreferenceCountry;

/**
 * @author sanjayakumar.das
 *
 */
public interface UserPrefCountryRepository extends JpaRepository<UserPreferenceCountry, Long>{

	List<UserPreferenceCountry> findPrefByCountryName(String name);

}