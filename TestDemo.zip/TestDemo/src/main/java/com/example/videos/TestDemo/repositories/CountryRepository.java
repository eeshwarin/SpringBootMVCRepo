/**
 * 
 */
package com.example.videos.TestDemo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.videos.TestDemo.model.Country;
import com.example.videos.TestDemo.model.User;

/**
 * @author sanjayakumar.das
 *
 */
@Repository
public interface CountryRepository extends JpaRepository<Country, Long>{

	Country findByName(String name);

}