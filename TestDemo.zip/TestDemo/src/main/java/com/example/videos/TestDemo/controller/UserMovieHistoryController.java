/**
 * 
 */
package com.example.videos.TestDemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.videos.TestDemo.model.UserMovieHistory;
import com.example.videos.TestDemo.repositories.UserMovieHistoryRepository;

/**
 * @author sanjayakumar.das
 *
 */
@RestController
@RequestMapping(value="/movieHistory")
public class UserMovieHistoryController {
	
	@Autowired
	private UserMovieHistoryRepository userMovieHistoryRepository;
	
	@GetMapping(value="/findAll")
	public List<UserMovieHistory> findUserMovieHistory(){
		
		return userMovieHistoryRepository.findAll();
	}
	
	@GetMapping(value="/findMovieByUserName/{name}")
	public List<UserMovieHistory> findMovieByUserName(@PathVariable final String name){
				
		return userMovieHistoryRepository.findMovieByUserName(name);
	}
	
	@PostMapping(value="/saveUserMovieHistory")
	public String saveUserMovieHistory(@RequestBody final UserMovieHistory userMovieHistory){
		userMovieHistoryRepository.save(userMovieHistory);
		System.out.println("UserMovieHistory Data Persisted Successfully**************");
		return "UserMovieHistory Data Persisted Successfully";
	}

}