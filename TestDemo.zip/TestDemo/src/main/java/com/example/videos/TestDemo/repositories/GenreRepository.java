/**
 * 
 */
package com.example.videos.TestDemo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.videos.TestDemo.model.Genre;

/**
 * @author sanjayakumar.das
 *
 */
public interface GenreRepository extends JpaRepository<Genre, Long>{

}