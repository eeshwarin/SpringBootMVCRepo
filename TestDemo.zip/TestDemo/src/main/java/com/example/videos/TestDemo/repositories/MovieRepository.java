/**
 * 
 */
package com.example.videos.TestDemo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.videos.TestDemo.model.Movie;

/**
 * @author sanjayakumar.das
 *
 */
public interface MovieRepository extends JpaRepository<Movie, Long>{

	Movie findByName(String name);

}