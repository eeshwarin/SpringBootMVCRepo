/**
 * 
 */
package com.example.videos.TestDemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.videos.TestDemo.model.Country;
import com.example.videos.TestDemo.model.User;
import com.example.videos.TestDemo.repositories.CountryRepository;

/**
 * @author sanjayakumar.das
 *
 */
@RestController
@RequestMapping("/countryDetails")
public class CountryController {
	
	@Autowired
	private CountryRepository countryRepository;
	
	@GetMapping(value="/findAllCountries")
	public List<Country> getAllCountries(){
		return countryRepository.findAll();
	}
	
	@GetMapping(value="/{name}")
	public Country getCountry(@PathVariable final String name){		
		return countryRepository.findByName(name);
	}
	
	@PostMapping(value="/saveCountry")
	public Country saveCountry(@RequestBody final Country country){
		countryRepository.save(country);
		System.out.println("Country Data Persisted Successfully**************");
		return countryRepository.findByName(country.getName());
	}

}