/**
 * 
 */
package com.example.videos.TestDemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.videos.TestDemo.model.Movie;
import com.example.videos.TestDemo.repositories.MovieRepository;

/**
 * @author sanjayakumar.das
 *
 */
@RestController
@RequestMapping(value="/movieDetails")
public class MovieController {

	@Autowired
	private MovieRepository movieRepository;
	
	@GetMapping(value="/findAllMovies")
	public List<Movie> findAllMovies(){
		List<Movie> movieList =  movieRepository.findAll();
		return movieList;
	}
	
	@GetMapping(value="/{name}")
	public Movie findMovie(@PathVariable final String name){
		return movieRepository.findByName(name);
	}
	
	@PostMapping(value="/saveMovie")
	public Movie saveMovie(@RequestBody final Movie movie){
		movieRepository.save(movie);
		System.out.println("Movie Data Persisted Successfully**************");
		return movieRepository.findByName(movie.getName());
	}
}