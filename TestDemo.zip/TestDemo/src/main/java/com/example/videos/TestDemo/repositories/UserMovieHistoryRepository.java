/**
 * 
 */
package com.example.videos.TestDemo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.videos.TestDemo.model.UserMovieHistory;
import com.example.videos.TestDemo.model.UserPreferenceCountry;

/**
 * @author sanjayakumar.das
 *
 */
public interface UserMovieHistoryRepository extends JpaRepository<UserMovieHistory, Long> {

	List<UserMovieHistory> findMovieByUserName(String name);



}