/**
 * 
 */
package com.example.videos.TestDemo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.videos.TestDemo.model.UserPreferenceCountry;
import com.example.videos.TestDemo.model.UserPreferenceGenre;

/**
 * @author sanjayakumar.das
 *
 */
public interface UserPrefGenreRepository extends JpaRepository<UserPreferenceGenre, Long>{
	List<UserPreferenceGenre> findPrefByGenreName(String name);
}