/**
 * 
 */
package com.example.videos.TestDemo.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author sanjayakumar.das
 *
 */
@Entity
@Table(name="USER_PREFERENCE_COUNTRY")
public class UserPreferenceCountry {	

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "USER_ID")	
	private User user;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "COUNTRY_ID")
	private Country country;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "MOVIE_ID")
	private Movie movie;	
	
	@Column(name="MOVIE_VIEW_DATE")
	@JsonProperty("movieViewDate")
	@JsonFormat(pattern = "YYYY-mm-dd")
	private Date movieViewDate;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Date getMovieViewDate() {
		return movieViewDate;
	}

	public void setMovieViewDate(Date movieViewDate) {
		this.movieViewDate = movieViewDate;
	}
}