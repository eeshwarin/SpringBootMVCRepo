/**
 * 
 */
package com.example.videos.TestDemo.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author sanjayakumar.das
 *
 */
@Entity
@Table(name = "Country")
public class Country {
	@Id
	@Column(name ="COUNTRY_ID")
	@JsonProperty("countryId")
	private Long countryId;
	
	@Column(name ="NAME")
	@JsonProperty("name")
	private String name;

	/*@OneToMany(cascade={CascadeType.ALL})
	@Fetch(FetchMode.JOIN)
	@JoinColumn(name="COUNTRY_ID", referencedColumnName="COUNTRY_ID")
	private Set<Movie> movies;
	private Set<Movie> movies;*/

	public Long getCountryId() {
		return countryId;
	}
	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	/*@OneToMany(fetch = FetchType.EAGER, mappedBy = "country")
    @JsonManagedReference
	public Set<Movie> getMovies() {
		return movies;
	}
	public void setMovies(Set<Movie> movies) {
		this.movies = movies;
	}*/

}