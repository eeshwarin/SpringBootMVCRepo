/**
 * 
 */
package com.example.videos.TestDemo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author sanjayakumar.das
 *
 */
@Entity
@Table(name = "GENRE")
public class Genre {
	
	@Id
	@Column(name ="GENRE_ID")	
	@JsonProperty("genreId")
	private Long genreId;
	
	@Column(name ="NAME")
	@JsonProperty("name")
	private String name;
	
	public Long getGenreId() {
		return genreId;
	}
	public void setGenreId(Long genreId) {
		this.genreId = genreId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}