/**
 * 
 */
package com.example.videos.TestDemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.videos.TestDemo.model.UserPreferenceGenre;
import com.example.videos.TestDemo.repositories.UserPrefGenreRepository;

/**
 * @author sanjayakumar.das
 *
 */
@RestController
@RequestMapping(value="/prefByGenreDetails")
public class UserPreferenceGenreController {
	
	@Autowired
	private UserPrefGenreRepository userPrefGenreRepository;
	
	@GetMapping(value="/findAll")
	public List<UserPreferenceGenre> findUserPreferenceByGenre(){
		
		return userPrefGenreRepository.findAll();
	}
	
	@GetMapping(value="/findByGenre/{name}")
	public List<UserPreferenceGenre> findPrefByGenreName(@PathVariable final String name){
				
		return userPrefGenreRepository.findPrefByGenreName(name);
	}
	
	@PostMapping(value="/savePrefByGenre")
	public String savePrefByGenre(@RequestBody final UserPreferenceGenre userPreferenceGenre){
		userPrefGenreRepository.save(userPreferenceGenre);
		System.out.println("UserPrefByGenre Data Persisted Successfully**************");
		return "UserPrefByGenre Data Persisted Successfully";
	}
	

}