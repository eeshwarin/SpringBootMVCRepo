/**
 * 
 */
package com.example.videos.TestDemo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author sanjayakumar.das
 *
 */
@Entity
@Table(name = "Movie")
public class Movie {
	
	@Id
	@Column(name="MOVIE_ID")
	@JsonProperty("movieId")
	private Long movieId;
	
	@Column(name="NAME")
	@JsonProperty("name")
	private String name;
	
	@Column(name="RELEASED_YEAR")
	@JsonProperty("releasedYear")
	@JsonFormat(pattern = "YYYY-mm-dd")
	private Date releasedYear;
	
	@Column(name="LIKE_COUNT")
	@JsonProperty("likeCount")
	private Long likeCount;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "COUNTRY_ID")
	private Country country;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "GENRE_ID")
	private Genre genre;

	public Long getMovieId() {
		return movieId;
	}
	public void setMovieId(Long movieId) {
		this.movieId = movieId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}	
	public Date getReleasedYear() {
		return releasedYear;
	}
	public void setReleasedYear(Date releasedYear) {
		this.releasedYear = releasedYear;
	}
	public Long getLikeCount() {
		return likeCount;
	}
	public void setLikeCount(Long likeCount) {
		this.likeCount = likeCount;
	}
	
	public Country getCountry() {
		return country;
	}
	public void setCountry(Country country) {
		this.country = country;
	}
	public Genre getGenre() {
		return genre;
	}
	public void setGenre(Genre genre) {
		this.genre = genre;
	}
}