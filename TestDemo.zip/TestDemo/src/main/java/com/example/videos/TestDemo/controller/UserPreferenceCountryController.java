/**
 * 
 */
package com.example.videos.TestDemo.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.videos.TestDemo.model.UserPreferenceCountry;
import com.example.videos.TestDemo.repositories.UserPrefCountryRepository;

/**
 * @author sanjayakumar.das
 *
 */
@RestController
@RequestMapping(value="/prefByCountryDetails")
public class UserPreferenceCountryController {
	
	@Autowired
	private UserPrefCountryRepository userPrefCountryRepository;
	
	@GetMapping(value="/findAll")
	public List<UserPreferenceCountry> findUserPreferenceByCountry(){
		
		return userPrefCountryRepository.findAll();
	}
	
	@GetMapping(value="/findByCountry/{name}")
	public List<UserPreferenceCountry> findPrefByCountryName(@PathVariable final String name){
				
		return userPrefCountryRepository.findPrefByCountryName(name);
	}
	
	@PostMapping(value="/savePrefByCountry")
	public String savePrefByCountry(@RequestBody final UserPreferenceCountry userPreferenceCountry){
		userPrefCountryRepository.save(userPreferenceCountry);
		System.out.println("UserPrefByCountry Data Persisted Successfully**************");
		return "UserPrefByCountry Data Persisted Successfully";
	}

}